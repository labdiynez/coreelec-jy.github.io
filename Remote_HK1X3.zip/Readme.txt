English:
Copy hk1x3 to /storage/.config/rc_keymaps
Copy rc_maps.cfg to /storage/.config

Español:
Copia hk1x3 a /storage/.config/rc_keymaps
Copia rc_maps.cfg a /storage/.config