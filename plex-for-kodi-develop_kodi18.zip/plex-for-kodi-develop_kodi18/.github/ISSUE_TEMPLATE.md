## Description:

## Details:
- Add-on version:
- Kodi version:
- OS Platform:
- Hardware:

## Checklist
- [ ] I have included a link to a log (or at the very least a link to a forum post with a log) from a session that had the issue
- [ ] I have added appropriate GitHub labels
